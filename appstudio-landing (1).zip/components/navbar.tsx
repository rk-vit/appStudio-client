import Link from "next/link"
import { Code } from "lucide-react"

export default function Navbar() {
  return (
    <nav className="fixed w-full bg-black bg-opacity-50 backdrop-blur-md z-10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          <div className="flex items-center">
            <Link href="/" className="flex items-center">
              <Code className="h-8 w-8 text-blue-500" />
              <span className="ml-2 text-xl font-bold">appStudio</span>
            </Link>
          </div>
          <div className="hidden md:block">
            <div className="ml-10 flex items-baseline space-x-4">
              <Link href="#" className="hover:bg-gray-700 px-3 py-2 rounded-md text-sm font-medium">
                Home
              </Link>
              <Link href="#" className="hover:bg-gray-700 px-3 py-2 rounded-md text-sm font-medium">
                Services
              </Link>
              <Link href="#" className="hover:bg-gray-700 px-3 py-2 rounded-md text-sm font-medium">
                About
              </Link>
              <Link href="#" className="hover:bg-gray-700 px-3 py-2 rounded-md text-sm font-medium">
                Contact
              </Link>
            </div>
          </div>
        </div>
      </div>
    </nav>
  )
}

